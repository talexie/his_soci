self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "97dc8e4e8a29ca6345f15d190ad24b58",
    "url": "./index.html"
  },
  {
    "revision": "fbaa3ec06e816af93f90",
    "url": "./static/css/2.18fb2ca0.chunk.css"
  },
  {
    "revision": "f9fc0c4fcf25add1d56a",
    "url": "./static/css/main.fe882306.chunk.css"
  },
  {
    "revision": "fbaa3ec06e816af93f90",
    "url": "./static/js/2.fa9228bd.chunk.js"
  },
  {
    "revision": "4e786d736663a2f2deb50ba9b91ad8e1",
    "url": "./static/js/2.fa9228bd.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f9fc0c4fcf25add1d56a",
    "url": "./static/js/main.3f04fb6c.chunk.js"
  },
  {
    "revision": "cfdc5b8f1b970e1a8943",
    "url": "./static/js/runtime-main.022d0135.js"
  }
]);