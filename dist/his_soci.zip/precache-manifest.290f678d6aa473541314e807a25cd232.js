self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1362a5f2c18d0181b0befb1cde1660c1",
    "url": "./index.html"
  },
  {
    "revision": "1c4aa12c707f37a2f7b5",
    "url": "./static/css/2.18fb2ca0.chunk.css"
  },
  {
    "revision": "7bee84d47499ed14b6d9",
    "url": "./static/css/main.fe882306.chunk.css"
  },
  {
    "revision": "1c4aa12c707f37a2f7b5",
    "url": "./static/js/2.b98f4c8f.chunk.js"
  },
  {
    "revision": "6fd1ba4ecd414b3983d25e0df4869f11",
    "url": "./static/js/2.b98f4c8f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7bee84d47499ed14b6d9",
    "url": "./static/js/main.6e0238f2.chunk.js"
  },
  {
    "revision": "8a629095aa1473504d7e",
    "url": "./static/js/runtime-main.a76d197f.js"
  }
]);