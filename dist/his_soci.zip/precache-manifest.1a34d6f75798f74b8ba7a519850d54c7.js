self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a92819c284c80f59863a882ce4c6fa53",
    "url": "./index.html"
  },
  {
    "revision": "fbaa3ec06e816af93f90",
    "url": "./static/css/2.18fb2ca0.chunk.css"
  },
  {
    "revision": "2f95cef583088c235dae",
    "url": "./static/css/main.fe882306.chunk.css"
  },
  {
    "revision": "fbaa3ec06e816af93f90",
    "url": "./static/js/2.fa9228bd.chunk.js"
  },
  {
    "revision": "4e786d736663a2f2deb50ba9b91ad8e1",
    "url": "./static/js/2.fa9228bd.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2f95cef583088c235dae",
    "url": "./static/js/main.d7a5939f.chunk.js"
  },
  {
    "revision": "cfdc5b8f1b970e1a8943",
    "url": "./static/js/runtime-main.022d0135.js"
  }
]);